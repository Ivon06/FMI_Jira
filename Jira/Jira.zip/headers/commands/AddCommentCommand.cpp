#include "AddCommentCommand.h"

AddCommentCommand::AddCommentCommand(const std::vector<std::string>& args) : Command(args)
{
}

void AddCommentCommand::execute(Context& context){

	std::string description;

	std::cin >> description;


}
